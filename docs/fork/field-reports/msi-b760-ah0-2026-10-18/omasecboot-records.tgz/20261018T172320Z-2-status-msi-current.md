# Acceptance record 2-status-msi-current

- Row: `2-status-msi-current`
- Recorded: 20261018T172320Z
- Command: `/usr/bin/omasecboot status`
- Evidence: counts

## State before


### Time (UTC)

```text
$ date -u +%Y-%m-%dT%H:%M:%SZ
2026-10-18T17:23:20Z
```

### Kernel

```text
$ uname -r
7.2.8-9-omarchy
```

### Firmware and machine model

```text
$ bash -c for f in sys_vendor product_name product_family bios_vendor bios_version bios_date; do printf "%s=%s\n" "$f" "$(cat /sys/class/dmi/id/$f 2>/dev/null)"; done
sys_vendor=Micro-Star International Co., Ltd.
product_name=MS-7D99
product_family=Default string
bios_vendor=American Megatrends International, LLC.
bios_version=A.H0
bios_date=08/25/2026
```

### Omarchy version

```text
$ bash -c pacman -Q omarchy omarchy-settings 2>&1; cat /usr/share/omarchy/version 2>/dev/null
omarchy 4.0.5-1
omarchy-settings 4.0.5-1
4.0.0.alpha
```

### Related packages

```text
$ pacman -Q omasecboot limine limine-mkinitcpio-hook limine-snapper-sync sbctl efibootmgr snapper systemd jq gum
omasecboot 0.1.1-1
limine 12.9.3-1
limine-mkinitcpio-hook 1.40.0-2
limine-snapper-sync 1.32.1-2
sbctl 0.18-2
efibootmgr 18-4
snapper 0.13.2-1
systemd 262-1
jq 1.8.2-1
gum 2.0.2-1
```

### Checkout revision and uncommitted changes

```text
$ bash -c git -C '/home/user/Documents/github/omasecboot' rev-parse HEAD 2>&1; git -C '/home/user/Documents/github/omasecboot' status --porcelain 2>&1 | sed 's/^/changed: /'
b0aae6469f10ab1947521cd287e7c64734f2d21e
```

### Installed files versus the checkout

```text
$ compare_installed_files
match: /etc/boot/hooks/post.d/90-omasecboot-sign
match: /usr/bin/omasecboot
match: /usr/lib/omasecboot/checks.sh
match: /usr/lib/omasecboot/common.sh
match: /usr/lib/omasecboot/files.sh
match: /usr/lib/omasecboot/firmware.sh
match: /usr/lib/omasecboot/limine.sh
match: /usr/lib/omasecboot/sign.sh
match: /usr/lib/omasecboot/status.sh
match: /usr/lib/omasecboot/windows.sh
match: /usr/lib/systemd/system/omasecboot-watch@.path
match: /usr/lib/systemd/system/omasecboot-watch@.service
```

### Limine hook directories

```text
$ bash -c ls -la /etc/boot/hooks/pre.d /etc/boot/hooks/post.d 2>&1
/etc/boot/hooks/post.d:
total 16
drwxr-xr-x 1 root root  196 Oct 18 20:46 .
drwxr-xr-x 1 root root   22 Oct 18 15:21 ..
-rwxr-xr-x 1 root root  989 Oct  8 20:21 89-warn-missing-file-hashes
lrwxrwxrwx 1 root root   29 Oct  8 20:21 90-limine-enroll-config -> /usr/bin/limine-enroll-config
-rwxr-xr-x 1 root root  658 Oct 18 18:26 90-omasecboot-sign
-rwxr-xr-x 1 root root 1087 Oct  8 20:21 91-example-esp-set-ro.disabled

/etc/boot/hooks/pre.d:
total 8
drwxr-xr-x 1 root root  104 Oct 18 15:40 .
drwxr-xr-x 1 root root   22 Oct 18 15:21 ..
-rwxr-xr-x 1 root root 1013 Oct  8 20:21 05-example-esp-set-rw.disabled
lrwxrwxrwx 1 root root   28 Oct  8 20:21 10-limine-reset-enroll -> /usr/bin/limine-reset-enroll
```

### pacman hooks that name Limine or this tool

```text
$ bash -c grep -l -i -E "limine|omasecboot" /etc/pacman.d/hooks/*.hook /usr/share/libalpm/hooks/*.hook 2>/dev/null | while IFS= read -r hook; do printf "%s (%s)\n" "$hook" "$(pacman -Qqo "$hook" 2>/dev/null || echo "owned by no package")"; grep -E "^(Operation|Target|When|Exec) *=" "$hook" | sed "s/^/    /"; done
/etc/pacman.d/hooks/90-mkinitcpio-install.hook (limine-mkinitcpio-hook)
    Operation = Install
    Operation = Upgrade
    Operation = Remove
    Target = usr/lib/initcpio/*
    Target = usr/lib/firmware/*
    Target = usr/lib/modules/*/extramodules/
    Target = usr/src/*/dkms.conf
    Target = usr/lib/systemd/systemd
    Target = usr/bin/cryptsetup
    Target = usr/bin/lvm
    Operation = Install
    Operation = Upgrade
    Target = usr/lib/modules/*/modules.builtin
    Operation = Install
    Operation = Upgrade
    Target = mkinitcpio
    Target = mkinitcpio-git
    When = PostTransaction
    Exec = /usr/share/libalpm/scripts/limine-mkinitcpio-install
/etc/pacman.d/hooks/99-omarchy-limine.hook (owned by no package)
    Operation = Upgrade
    Target = limine
    When = PostTransaction
    Exec = /bin/sh -c "/usr/bin/cp /usr/share/limine/BOOTX64.EFI /boot/EFI/limine/limine_x64.efi"
/usr/share/libalpm/hooks/10-limine-snapper-lock.hook (limine-snapper-sync)
    Operation = Upgrade
    Operation = Install
    Operation = Remove
    Target = *
    When = PreTransaction
    Exec = /usr/share/libalpm/scripts/limine-snapper-lock
/usr/share/libalpm/hooks/60-limine-mkinitcpio-remove-pre.hook (limine-mkinitcpio-hook)
    Operation = Remove
    Target = usr/lib/modules/*/modules.builtin
    When = PreTransaction
    Exec = /usr/share/libalpm/scripts/limine-mkinitcpio-remove pre
/usr/share/libalpm/hooks/80-limine-efi-deploy.hook (limine-mkinitcpio-hook)
    Operation = Install
    Operation = Upgrade
    Target = limine
    Target = limine-git
    Target = limine-dev
    Target = limine-mkinitcpio-hook
    Target = limine-mkinitcpio-hook-git
    When = PostTransaction
    Exec = /usr/bin/limine-install
/usr/share/libalpm/hooks/90-limine-mkinitcpio-remove-post.hook (limine-mkinitcpio-hook)
    Operation = Remove
    Target = usr/lib/modules/*/modules.builtin
    When = PostTransaction
    Exec = /usr/share/libalpm/scripts/limine-mkinitcpio-remove post
```

### Secure Boot variables

```text
$ bash -c for v in SecureBoot SetupMode AuditMode DeployedMode; do p=$(ls /sys/firmware/efi/efivars/${v}-* 2>/dev/null | head -1); if [[ -n $p ]]; then printf "%s=%s\n" "$v" "$(od -An -tu1 -j4 -N1 "$p" | tr -d " ")"; else printf "%s=absent\n" "$v"; fi; done
SecureBoot=1
SetupMode=0
AuditMode=0
DeployedMode=0
```

### sbctl status

```text
$ sbctl status
Installed:	✓ sbctl is installed
Owner GUID:	uuid-4
Setup Mode:	✓ Disabled
Secure Boot:	✓ Enabled
Vendor Keys:	microsoft builtin-db builtin-KEK
Firmware:	‼ Your firmware has known quirks
		- FQ0001: Defaults to executing on Secure Boot policy violation (CRITICAL)
		  https://github.com/Foxboron/sbctl/wiki/FQ0001
```

### sbctl list-files

```text
$ sbctl list-files
```

### sbctl verify

```text
$ sbctl verify
Verifying file database and EFI images in /boot...
✗ /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6 is not signed
✓ /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695 is signed
✗ /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3 is not signed
✗ /boot/EFI/BOOT/BOOTX64.EFI is not signed
✓ /boot/EFI/Linux/omarchy_linux-omarchy.efi is signed
✓ /boot/EFI/limine/limine_x64.efi is signed
```

### omasecboot status

```text
$ bash -c if command -v omasecboot >/dev/null; then omasecboot status; printf "exit status: %s\n" "$?"; else echo "omasecboot is not installed"; fi

OmaSecBoot - Status

  ✓ Secure Boot is on
  ✓ Your keys are enrolled in the firmware
  ! sbctl reports firmware quirk FQ0001: Defaults to executing on Secure Boot policy violation (CRITICAL); https://github.com/Foxboron/sbctl/wiki/FQ0001
  · Firmware quirks are hardware matches, not a test of the current policy; review the linked guidance and the firmware's Secure Boot image execution policy
  ✓ ENABLE_VERIFICATION=no is in effect
  ✓ ENABLE_ENROLL_LIMINE_CONFIG=yes is in effect
  ✓ The Limine loader is sealed over the current limine.conf and signed
  ✓ The fallback loader is upstream's raw copy, the rescue loader when Secure Boot is off
  ✓ sbctl's signing keys exist
  ✓ Signed: /boot/EFI/Linux/omarchy_linux-omarchy.efi
  ✓ Signed: /boot/EFI/limine/limine_x64.efi
  · 2 snapshot image(s) predate Secure Boot setup and are unsigned: those entries boot only with Secure Boot off. They leave with snapshot rotation, or within seconds when those snapshots are deleted (sudo snapper -c root delete NUMBER)
  ✓ The Windows entry restarts the machine into Windows Boot Manager
  ✓ The Limine hook is installed
  ✓ The watchers of limine.conf and the loader are active
  → Nothing to do
exit status: 0
```

### omasecboot windows status

```text
$ bash -c if command -v omasecboot >/dev/null; then omasecboot windows status 2>&1; else echo "omasecboot is not installed"; fi

OmaSecBoot - Windows

  ✓ Target: Boot0000, Windows Boot Manager
  ✓ limine.conf holds the entry for this target, once
  · The Windows entry is enabled
```

### BootNext

```text
$ bash -c p=$(ls /sys/firmware/efi/efivars/BootNext-* 2>/dev/null | head -1); if [[ -n $p ]]; then od -An -tx1 -j4 "$p"; else echo absent; fi
absent
```

### Watchers

```text
$ bash -c systemctl list-units --all --no-pager "omasecboot-watch@*" 2>&1; systemctl list-unit-files --no-pager "omasecboot-watch@*" 2>&1
  UNIT                                                    LOAD   ACTIVE   SUB     DESCRIPTION
  omasecboot-watch@boot-EFI-limine-limine_x64.efi.path    loaded active   waiting Watch /boot/EFI/limine/limine_x64.efi for OmaSecBoot
  omasecboot-watch@boot-limine.conf.path                  loaded active   waiting Watch /boot/limine.conf for OmaSecBoot
  omasecboot-watch@boot-EFI-limine-limine_x64.efi.service loaded inactive dead    Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed
  omasecboot-watch@boot-limine.conf.service               loaded inactive dead    Re-seal the Limine loader after /boot/limine.conf changed

Legend: LOAD   → Reflects whether the unit definition was properly loaded.
        ACTIVE → The high-level unit activation state, i.e. generalization of SUB.
        SUB    → The low-level unit activation state, values depend on unit type.

4 loaded units listed.
To show all installed unit files use 'systemctl list-unit-files'.
UNIT FILE                 STATE    PRESET
omasecboot-watch@.path    indirect disabled
omasecboot-watch@.service static   -

2 unit files listed.
```

### Boot entries (MAC and NVMe nodes redacted, raw bytes left out)

```text
$ boot_entries
BootCurrent: 0003
Timeout: 0 seconds
BootOrder: 0003,0000,0004
Boot0000* Windows Boot Manager	HD(1,GPT,uuid-1,0x800,0x64000)/\EFI\Microsoft\Boot\bootmgfw.efi (optional data left out)
Boot0003* Limine	HD(1,GPT,uuid-2,0x800,0x400000)/\EFI\limine\limine_x64.efi
Boot0004* UEFI OS	HD(1,GPT,uuid-2,0x800,0x400000)/\EFI\BOOT\BOOTX64.EFI (optional data left out)
```

### ESP mount, free space and partitions

```text
$ bash -c findmnt -o TARGET,SOURCE,FSTYPE,OPTIONS $esp 2>&1; df -h $esp 2>&1; lsblk -o NAME,SIZE,FSTYPE,PARTTYPENAME,MOUNTPOINTS 2>&1
TARGET SOURCE         FSTYPE OPTIONS
/boot  /dev/nvme1n1p1 vfat   rw,relatime,fmask=0077,dmask=0077,codepage=437,iocharset=ascii,shortname=mixed,utf8,errors=remount-ro
Filesystem      Size  Used Avail Use% Mounted on
/dev/nvme1n1p1  2.0G  1.1G 1018M  51% /boot
NAME          SIZE FSTYPE      PARTTYPENAME                 MOUNTPOINTS
zram0          31G swap                                     [SWAP]
nvme1n1     476.9G                                          
├─nvme1n1p1     2G vfat        EFI System                   /boot
└─nvme1n1p2 474.9G crypto_LUKS Linux root (x86-64)          
  └─root    474.9G btrfs                                    /var/log
                                                            /home
                                                            /var/cache/pacman/pkg
                                                            /
nvme0n1     931.5G                                          
├─nvme0n1p1   200M vfat        EFI System                   
├─nvme0n1p2    16M             Microsoft reserved           
├─nvme0n1p3 930.5G ntfs        Microsoft basic data         
└─nvme0n1p4   866M ntfs        Windows recovery environment 
```

### EFI files

```text
$ bash -c find $esp/EFI -type f \( -iname "*.efi" -o -name "*.efi_*" \) -exec sha256sum {} + 2>/dev/null | sort -k2
94308b4e9ee1783a65cfd60570240a80595baf125c5b18e729d3dd977194ad51  /boot/EFI/BOOT/BOOTX64.EFI
a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695  /boot/EFI/Linux/omarchy_linux-omarchy.efi
aaa999727d5cc105ef79307b8dea177a52719b511c39eebf5984e00a8d169136  /boot/EFI/limine/limine_x64.efi
```

### Snapshot images kept by limine-snapper-sync

```text
$ bash -c find $esp -path "*/limine_history/*" -type f -exec sha256sum {} + 2>/dev/null | sort -k2
521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6  /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6
a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695  /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695
cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3  /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3
f8292492bd6d6eb3ac6a1350ec0040fe75aef6b12ef458aba12f3a682386f61e  /boot/id-1/limine_history/snapshots.json
b7001369dbdc3b055d7db0aabc22910732d1d07c3abeffa10d03e4998adbdf72  /boot/id-1/limine_history/snapshots.json.old
```

### Snapshot list kept by limine-snapper-sync (first 60 lines)

```text
$ bash -c find $esp -path "*/limine_history/snapshots.json" -exec head -n 60 {} + 2>&1
{
  "jsonFormatVersion" : "1.3.0",
  "lastSnapshotID" : 4,
  "lastTimestamp" : "2026-10-18 22:33:39",
  "lastUTCTime" : "2026-10-18 17:03:39",
  "properties" : {
    "SNAPSHOTS_PATH" : "/@/.snapshots",
    "SUBVOLUME_PATH" : "/@"
  },
  "snapshotEntries" : [ {
    "snapperID" : {
      "snapshotID" : 1,
      "utcTime" : "2026-10-18 10:08:21",
      "timestamp" : "2026-10-18 15:38:21",
      "properties" : {
        "description" : "4.0.4-1",
        "type" : "single"
      }
    },
    "kernelEntries" : [ {
      "kernelVersion" : "linux-omarchy",
      "leadingSpaces" : "  ",
      "optionDetails" : [ {
        "limineKey" : "COMMENT",
        "leadingSpaces" : "  ",
        "lineIndex" : 0,
        "optionLine" : "Kernel version: 7.2.5-3-omarchy",
        "snapshotOptionLine" : "Kernel version: 7.2.5-3-omarchy",
        "properties" : { }
      }, {
        "limineKey" : "COMMENT",
        "leadingSpaces" : "  ",
        "lineIndex" : 1,
        "optionLine" : "kernel-id=linux-omarchy",
        "snapshotOptionLine" : "kernel-id=linux-omarchy",
        "properties" : { }
      }, {
        "limineKey" : "PROTOCOL",
        "leadingSpaces" : "  ",
        "lineIndex" : 2,
        "optionLine" : "efi",
        "snapshotOptionLine" : "efi",
        "properties" : { }
      } ],
      "imageDetails" : [ {
        "limineKey" : "PATH",
        "leadingSpaces" : "  ",
        "lineIndex" : 3,
        "fileName" : "omarchy_linux-omarchy.efi",
        "fileHashName" : "omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6",
        "dirPath" : "/EFI/Linux/",
        "filePathLine" : "/EFI/Linux/omarchy_linux-omarchy.efi",
        "snapshotFilePathLine" : "/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6#099ef9a0a25a193e749100c3d69d803f758bae68e252002a06e14a8ec2c4a9739bb2898117d60c556cf6c7aa1904aa2d8d42c43111477556d0b38cbaa40b5234",
        "properties" : {
          "PATH_RESOURCE" : "boot():",
          "HASH" : "#099ef9a0a25a193e749100c3d69d803f758bae68e252002a06e14a8ec2c4a9739bb2898117d60c556cf6c7aa1904aa2d8d42c43111477556d0b38cbaa40b5234"
        }
      } ],
      "cmdlineDetails" : [ {
        "limineKey" : "CMDLINE",
```

### Snapshots

```text
$ bash -c snapper -c root list 2>&1
# │ Type   │ Pre # │ Date                     │ User │ Cleanup │ Description                                   │ Userdata
──┼────────┼───────┼──────────────────────────┼──────┼─────────┼───────────────────────────────────────────────┼─────────
0 │ single │       │                          │ root │         │ current                                       │
1 │ single │       │ Sun Oct 18 15:38:21 2026 │ root │ number  │ 4.0.4-1                                       │
2 │ single │       │ Sun Oct 18 16:29:48 2026 │ root │ number  │ 4.0.5-1                                       │
3 │ single │       │ Sun Oct 18 20:47:57 2026 │ root │         │ OmaSecBoot signed boot files; Secure Boot off │
4 │ single │       │ Sun Oct 18 22:33:39 2026 │ root │ number  │ 4.0.5-1                                       │
```

### Limine loader directories

```text
$ bash -c ls -la $esp/EFI/limine $esp/EFI/BOOT 2>&1
/boot/EFI/BOOT:
total 376
drwx------ 2 root root   4096 Oct 18 15:21 .
drwx------ 6 root root   4096 Oct 18 21:13 ..
-rwx------ 1 root root 376832 Oct 18 15:41 BOOTX64.EFI

/boot/EFI/limine:
total 752
drwx------ 2 root root   4096 Oct 18 22:33 .
drwx------ 6 root root   4096 Oct 18 21:13 ..
-rwx------ 1 root root 378880 Oct 18 15:41 limine_x64.bak
-rwx------ 1 root root 378936 Oct 18 22:33 limine_x64.efi
```

### Limine path hashes versus files

```text
$ bash -c grep -o "boot():/[^#[:space:]]*#[0-9A-Fa-f]\{128\}" $esp/limine.conf 2>/dev/null | sort -u | while IFS= read -r uri; do file="$esp/${uri#boot():/}"; file="${file%#*}"; hash="${uri##*#}"; if [ -f "$file" ]; then actual=$(b2sum "$file" | cut -d" " -f1); [ "$actual" = "$hash" ] && printf "match  %s\n" "$uri" || printf "STALE  %s\n" "$uri"; else printf "absent %s\n" "$uri"; fi; done; true
match  boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6#099ef9a0a25a193e749100c3d69d803f758bae68e252002a06e14a8ec2c4a9739bb2898117d60c556cf6c7aa1904aa2d8d42c43111477556d0b38cbaa40b5234
match  boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3#19a70ec0bd5d2ee0f2d35d97b615564007ba3cedcf39a3e2aa70182257aa574706e60227de550f793cf143a08bdf9dfb82fe36dc6cf748d8047fd3ff6cfc312f
```

### Config checksum in each loader (first 16 hex digits)

```text
$ bash -c for f in $esp/EFI/limine/limine_x64.efi $esp/EFI/BOOT/BOOTX64.EFI; do h=$(grep -a -o "++CONFIG_B2SUM_SIGNATURE++[0-9a-f]\{128\}" "$f" 2>/dev/null | head -1 | cut -c27-42); printf "%s: %s\n" "$f" "${h:-absent}"; done; printf "limine.conf b2sum: "; b2sum $esp/limine.conf | cut -c1-16
/boot/EFI/limine/limine_x64.efi: 2ad6d11394f48e51
/boot/EFI/BOOT/BOOTX64.EFI: 0000000000000000
limine.conf b2sum: 2ad6d11394f48e51
```

### Limine config layers (owner, mode, links)

```text
$ bash -c stat -c "%U:%G %a %h %n" /etc/default/limine /etc/limine-entry-tool.conf /etc/limine-entry-tool.d/*.conf /usr/share/limine-entry-tool.d/*.conf 2>&1
root:root 644 1 /etc/default/limine
root:root 644 1 /etc/limine-entry-tool.conf
root:root 644 1 /etc/limine-entry-tool.d/omarchy-defaults.conf
root:root 644 1 /etc/limine-entry-tool.d/omarchy-uki.conf
root:root 644 1 /etc/limine-entry-tool.d/resume.conf
stat: cannot statx '/usr/share/limine-entry-tool.d/*.conf': No such file or directory
```

### Limine drop-in settings

```text
$ bash -c grep -H -v "^[[:space:]]*#" /etc/limine-entry-tool.d/*.conf /usr/share/limine-entry-tool.d/*.conf 2>&1 | grep -v ":$"
/etc/limine-entry-tool.d/omarchy-defaults.conf:TARGET_OS_NAME="Omarchy"
/etc/limine-entry-tool.d/omarchy-defaults.conf:KERNEL_CMDLINE[default]+=" quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0"
/etc/limine-entry-tool.d/omarchy-defaults.conf:KERNEL_CMDLINE[default]+=" initramfs_async=0"
/etc/limine-entry-tool.d/omarchy-defaults.conf:KERNEL_CMDLINE[default]+=" systemd.tty.term.console=dumb"
/etc/limine-entry-tool.d/omarchy-defaults.conf:CUSTOM_UKI_NAME="omarchy"
/etc/limine-entry-tool.d/omarchy-defaults.conf:ENABLE_LIMINE_FALLBACK=yes
/etc/limine-entry-tool.d/omarchy-defaults.conf:FIND_BOOTLOADERS=yes
/etc/limine-entry-tool.d/omarchy-defaults.conf:BOOT_ORDER="linux-t2, linux-omarchy, linux-omarchy-*, *, *fallback, Snapshots"
/etc/limine-entry-tool.d/omarchy-defaults.conf:MAX_SNAPSHOT_ENTRIES=6
/etc/limine-entry-tool.d/omarchy-defaults.conf:SNAPSHOT_FORMAT_CHOICE=5
/etc/limine-entry-tool.d/omarchy-uki.conf:ENABLE_UKI=yes
/etc/limine-entry-tool.d/resume.conf:KERNEL_CMDLINE[default]+=" resume=/dev/mapper/root resume_offset=1906319"
grep: /usr/share/limine-entry-tool.d/*.conf: No such file or directory
```

### /etc/default/limine

```text
ESP_PATH="/boot"

KERNEL_CMDLINE[default]+="cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=@ rw rootfstype=btrfs"
ENABLE_VERIFICATION=no
ENABLE_ENROLL_LIMINE_CONFIG=yes
```

### limine.conf

```text
### Read more at config document: https://github.com/limine-bootloader/limine/blob/trunk/CONFIG.md
#timeout: 3
default_entry: 2
interface_branding: Omarchy Bootloader
interface_branding_color: 9ece6a
interface_help_color: 9ece6a
interface_help_color_bright: 9ece6a
hash_mismatch_panic: no

term_background: 1a1b26
backdrop: 1a1b26

# Terminal colors (Tokyo Night palette)
term_palette: 15161e;f7768e;9ece6a;e0af68;7aa2f7;bb9af7;7dcfff;a9b1d6
term_palette_bright: 414868;f7768e;9ece6a;e0af68;7aa2f7;bb9af7;7dcfff;c0caf5

# Text colors
term_foreground: c0caf5
term_foreground_bright: c0caf5
term_background_bright: 24283b
/+Omarchy
### This OS entry is auto-generated by limine-entry-tool
comment: Omarchy
comment: machine-id=id-1 order-priority=50 
  //linux-omarchy
  ### This kernel entry is auto-generated by limine-entry-tool
  comment: Kernel version: 7.2.8-9-omarchy
  comment: kernel-id=linux-omarchy 
  protocol: efi
  path: boot():/EFI/Linux/omarchy_linux-omarchy.efi
  cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=@ rw rootfstype=btrfs resume=/dev/mapper/root resume_offset=1906319 systemd.tty.term.console=dumb initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0

     //Snapshots
     ### Auto-generated by limine-snapper-sync
     comment: 4 snapshots
     ///4 │ 2026-10-18 22:33:39
     comment: 4.0.5-1
     ////linux-omarchy
     comment: Kernel version: 7.2.8-9-omarchy
     comment: kernel-id=linux-omarchy
     protocol: efi
     path: boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695
     cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=/@/.snapshots/4/snapshot rw rootfstype=btrfs resume=/dev/mapper/root resume_offset=1906319 systemd.tty.term.console=dumb initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0
     ///3 │ 2026-10-18 20:47:57
     comment: OmaSecBoot signed boot files; Secure Boot off
     ////linux-omarchy
     comment: Kernel version: 7.2.8-9-omarchy
     comment: kernel-id=linux-omarchy
     protocol: efi
     path: boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695
     cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=/@/.snapshots/3/snapshot rw rootfstype=btrfs resume=/dev/mapper/root resume_offset=1906319 systemd.tty.term.console=dumb initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0
     ///2 │ 2026-10-18 16:29:48
     comment: 4.0.5-1
     ////linux-omarchy
     comment: Kernel version: 7.2.8-9-omarchy
     comment: kernel-id=linux-omarchy
     protocol: efi
     path: boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3#19a70ec0bd5d2ee0f2d35d97b615564007ba3cedcf39a3e2aa70182257aa574706e60227de550f793cf143a08bdf9dfb82fe36dc6cf748d8047fd3ff6cfc312f
     cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=/@/.snapshots/2/snapshot rw rootfstype=btrfs resume=/dev/mapper/root resume_offset=1906319 systemd.tty.term.console=dumb initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0
     ///1 │ 2026-10-18 15:38:21
     comment: 4.0.4-1
     ////linux-omarchy
     comment: Kernel version: 7.2.5-3-omarchy
     comment: kernel-id=linux-omarchy
     protocol: efi
     path: boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6#099ef9a0a25a193e749100c3d69d803f758bae68e252002a06e14a8ec2c4a9739bb2898117d60c556cf6c7aa1904aa2d8d42c43111477556d0b38cbaa40b5234
     cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=/@/.snapshots/1/snapshot rw rootfstype=btrfs  resume=/dev/mapper/root resume_offset=1906319 initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0

/EFI fallback
### This EFI entry is auto-generated by limine-entry-tool
comment: Default EFI loader
comment: order-priority=10 
protocol: efi
path: boot():/EFI/BOOT/BOOTX64.EFI


/Windows
    comment: Windows Boot Manager through the firmware, managed by OmaSecBoot
    protocol: efi_boot_entry
    entry: Windows Boot Manager
```

### State directory

```text
$ bash -c ls -laR /var/lib/omasecboot 2>&1 | grep -v '^$'
/var/lib/omasecboot:
total 4
drwxr-xr-x 1 root root 110 Oct 18 22:11 .
drwxr-xr-x 1 root root 400 Oct 18 20:46 ..
-rw-r--r-- 1 root root   0 Oct 18 21:10 enabled
drwxr-xr-x 1 root root  32 Oct 18 20:46 firmware-backup
-rw-r--r-- 1 root root  62 Oct 18 20:46 settings-originals
-rw-r--r-- 1 root root   0 Oct 18 22:11 windows-enabled
/var/lib/omasecboot/firmware-backup:
total 0
drwxr-xr-x 1 root root  32 Oct 18 20:46 .
drwxr-xr-x 1 root root 110 Oct 18 22:11 ..
drwx------ 1 root root  50 Oct 18 20:46 20261018T151648Z
/var/lib/omasecboot/firmware-backup/20261018T151648Z:
total 52
drwx------ 1 root root    50 Oct 18 20:46 .
drwxr-xr-x 1 root root    32 Oct 18 20:46 ..
-rw------- 1 root root  3888 Oct 18 20:46 KEK
-rw------- 1 root root   821 Oct 18 20:46 PK
-rw------- 1 root root   350 Oct 18 20:46 SHA256SUMS
-rw------- 1 root root  8458 Oct 18 20:46 db
-rw------- 1 root root 21420 Oct 18 20:46 dbx
-rw------- 1 root root    25 Oct 18 20:46 modes
```

### Firmware backups (names and sizes only)

```text
$ bash -c find /var/lib/omasecboot/firmware-backup -type f -printf '%s %p\n' 2>/dev/null | sort -k2
3888 /var/lib/omasecboot/firmware-backup/20261018T151648Z/KEK
821 /var/lib/omasecboot/firmware-backup/20261018T151648Z/PK
350 /var/lib/omasecboot/firmware-backup/20261018T151648Z/SHA256SUMS
8458 /var/lib/omasecboot/firmware-backup/20261018T151648Z/db
21420 /var/lib/omasecboot/firmware-backup/20261018T151648Z/dbx
25 /var/lib/omasecboot/firmware-backup/20261018T151648Z/modes
```

### settings-originals

```text
ENABLE_VERIFICATION	absent
ENABLE_ENROLL_LIMINE_CONFIG	absent
```

### needs-attention

_absent_

### This boot's journal for omasecboot, limine, sbctl (last 200 lines)

```text
$ bash -c journalctl -b --no-pager -o short-iso 2>/dev/null | grep -i -E 'omasecboot|limine|sbctl|efibootmgr' | tail -200
2026-10-18T22:17:20+05:30 host systemd[1]: Started Watch /boot/EFI/limine/limine_x64.efi for OmaSecBoot.
2026-10-18T22:17:20+05:30 host systemd[1]: Started Watch /boot/limine.conf for OmaSecBoot.
2026-10-18T22:17:20+05:30 host systemd[1]: Started [limine-snapper-sync.service] automatically synchronizes boot entries with the Snapper snapshot list..
2026-10-18T22:17:23+05:30 host systemd[1271]: Starting Limine-snapper-restore notification...
2026-10-18T22:17:23+05:30 host systemd[1271]: Started Limine-snapper-restore notification.
2026-10-18T22:17:23+05:30 host limine-snapper-restore[1690]: You are not in a snapshot.
2026-10-18T22:27:16+05:30 host systemd[1]: Created slice Slice /system/omasecboot-watch.
2026-10-18T22:27:16+05:30 host systemd[1]: Starting Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed...
2026-10-18T22:27:16+05:30 host systemd[1]: Starting Re-seal the Limine loader after /boot/limine.conf changed...
2026-10-18T22:27:16+05:30 host limine-snapper-sync[339930]: Updated: /boot/limine.conf
2026-10-18T22:27:16+05:30 host limine-snapper-sync[340018]: Config file BLAKE2B successfully enrolled.
2026-10-18T22:27:17+05:30 host limine-snapper-sync[340034]: ✓ Signed /boot/EFI/limine/limine_x64.efi
2026-10-18T22:27:17+05:30 host systemd[1]: omasecboot-watch@boot-EFI-limine-limine_x64.efi.service: Deactivated successfully.
2026-10-18T22:27:17+05:30 host systemd[1]: Finished Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed.
2026-10-18T22:27:18+05:30 host systemd[1]: omasecboot-watch@boot-limine.conf.service: Deactivated successfully.
2026-10-18T22:27:18+05:30 host systemd[1]: Finished Re-seal the Limine loader after /boot/limine.conf changed.
2026-10-18T22:31:38+05:30 host sudo[345361]:      user : TTY=pts/1 ; PWD=/home/user ; USER=root ; COMMAND=/usr/bin/omasecboot status
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[1219]: [EVENT] CREATE,ISDIR -> 4
2026-10-18T22:33:39+05:30 host systemd[1]: Starting Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed...
2026-10-18T22:33:39+05:30 host systemd[1]: Starting Re-seal the Limine loader after /boot/limine.conf changed...
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[348187]: Saved: /boot/id-1/limine_history/snapshots.json
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[348187]: Updated: /boot/limine.conf
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[348363]: Config file BLAKE2B successfully enrolled.
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[348378]: ✓ Signed /boot/EFI/limine/limine_x64.efi
2026-10-18T22:33:40+05:30 host systemd[1]: omasecboot-watch@boot-EFI-limine-limine_x64.efi.service: Deactivated successfully.
2026-10-18T22:33:40+05:30 host systemd[1]: Finished Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed.
2026-10-18T22:33:43+05:30 host systemd[1]: omasecboot-watch@boot-limine.conf.service: Deactivated successfully.
2026-10-18T22:33:43+05:30 host systemd[1]: Finished Re-seal the Limine loader after /boot/limine.conf changed.
2026-10-18T22:53:20+05:30 host pkexec[433525]: user: Executing command [USER=root] [TTY=unknown] [CWD=/home/user/Documents/github/omasecboot] [COMMAND=/usr/bin/bash -c set -euo pipefail; export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/home/user/Documents/github/omasecboot; cd /home/user/Documents/github/omasecboot; /usr/bin/bash tests/acceptance-record.sh 2-status-msi-current -- /usr/bin/omasecboot status; chown user:user acceptance-records/*-2-status-msi-current.md]
```

## Command transcript

Running: `/usr/bin/omasecboot status`

```text
Script started on 2026-10-18 22:53:24+05:30 [COMMAND="/usr/bin/omasecboot status " <not executed on terminal>]

OmaSecBoot - Status

  ✓ Secure Boot is on
  ✓ Your keys are enrolled in the firmware
  ! sbctl reports firmware quirk FQ0001: Defaults to executing on Secure Boot policy violation (CRITICAL); https://github.com/Foxboron/sbctl/wiki/FQ0001
  · Firmware quirks are hardware matches, not a test of the current policy; review the linked guidance and the firmware's Secure Boot image execution policy
  ✓ ENABLE_VERIFICATION=no is in effect
  ✓ ENABLE_ENROLL_LIMINE_CONFIG=yes is in effect
  ✓ The Limine loader is sealed over the current limine.conf and signed
  ✓ The fallback loader is upstream's raw copy, the rescue loader when Secure Boot is off
  ✓ sbctl's signing keys exist
  ✓ Signed: /boot/EFI/Linux/omarchy_linux-omarchy.efi
  ✓ Signed: /boot/EFI/limine/limine_x64.efi
  · 2 snapshot image(s) predate Secure Boot setup and are unsigned: those entries boot only with Secure Boot off. They leave with snapshot rotation, or within seconds when those snapshots are deleted (sudo snapper -c root delete NUMBER)
  ✓ The Windows entry restarts the machine into Windows Boot Manager
  ✓ The Limine hook is installed
  ✓ The watchers of limine.conf and the loader are active
  → Nothing to do

Script done on 2026-10-18 22:53:25+05:30 [COMMAND_EXIT_CODE="0"]
```

Exit status: `0`

## State after


### Time (UTC)

```text
$ date -u +%Y-%m-%dT%H:%M:%SZ
2026-10-18T17:23:25Z
```

### Kernel

```text
$ uname -r
7.2.8-9-omarchy
```

### Firmware and machine model

```text
$ bash -c for f in sys_vendor product_name product_family bios_vendor bios_version bios_date; do printf "%s=%s\n" "$f" "$(cat /sys/class/dmi/id/$f 2>/dev/null)"; done
sys_vendor=Micro-Star International Co., Ltd.
product_name=MS-7D99
product_family=Default string
bios_vendor=American Megatrends International, LLC.
bios_version=A.H0
bios_date=08/25/2026
```

### Omarchy version

```text
$ bash -c pacman -Q omarchy omarchy-settings 2>&1; cat /usr/share/omarchy/version 2>/dev/null
omarchy 4.0.5-1
omarchy-settings 4.0.5-1
4.0.0.alpha
```

### Related packages

```text
$ pacman -Q omasecboot limine limine-mkinitcpio-hook limine-snapper-sync sbctl efibootmgr snapper systemd jq gum
omasecboot 0.1.1-1
limine 12.9.3-1
limine-mkinitcpio-hook 1.40.0-2
limine-snapper-sync 1.32.1-2
sbctl 0.18-2
efibootmgr 18-4
snapper 0.13.2-1
systemd 262-1
jq 1.8.2-1
gum 2.0.2-1
```

### Checkout revision and uncommitted changes

```text
$ bash -c git -C '/home/user/Documents/github/omasecboot' rev-parse HEAD 2>&1; git -C '/home/user/Documents/github/omasecboot' status --porcelain 2>&1 | sed 's/^/changed: /'
b0aae6469f10ab1947521cd287e7c64734f2d21e
```

### Installed files versus the checkout

```text
$ compare_installed_files
match: /etc/boot/hooks/post.d/90-omasecboot-sign
match: /usr/bin/omasecboot
match: /usr/lib/omasecboot/checks.sh
match: /usr/lib/omasecboot/common.sh
match: /usr/lib/omasecboot/files.sh
match: /usr/lib/omasecboot/firmware.sh
match: /usr/lib/omasecboot/limine.sh
match: /usr/lib/omasecboot/sign.sh
match: /usr/lib/omasecboot/status.sh
match: /usr/lib/omasecboot/windows.sh
match: /usr/lib/systemd/system/omasecboot-watch@.path
match: /usr/lib/systemd/system/omasecboot-watch@.service
```

### Limine hook directories

```text
$ bash -c ls -la /etc/boot/hooks/pre.d /etc/boot/hooks/post.d 2>&1
/etc/boot/hooks/post.d:
total 16
drwxr-xr-x 1 root root  196 Oct 18 20:46 .
drwxr-xr-x 1 root root   22 Oct 18 15:21 ..
-rwxr-xr-x 1 root root  989 Oct  8 20:21 89-warn-missing-file-hashes
lrwxrwxrwx 1 root root   29 Oct  8 20:21 90-limine-enroll-config -> /usr/bin/limine-enroll-config
-rwxr-xr-x 1 root root  658 Oct 18 18:26 90-omasecboot-sign
-rwxr-xr-x 1 root root 1087 Oct  8 20:21 91-example-esp-set-ro.disabled

/etc/boot/hooks/pre.d:
total 8
drwxr-xr-x 1 root root  104 Oct 18 15:40 .
drwxr-xr-x 1 root root   22 Oct 18 15:21 ..
-rwxr-xr-x 1 root root 1013 Oct  8 20:21 05-example-esp-set-rw.disabled
lrwxrwxrwx 1 root root   28 Oct  8 20:21 10-limine-reset-enroll -> /usr/bin/limine-reset-enroll
```

### pacman hooks that name Limine or this tool

```text
$ bash -c grep -l -i -E "limine|omasecboot" /etc/pacman.d/hooks/*.hook /usr/share/libalpm/hooks/*.hook 2>/dev/null | while IFS= read -r hook; do printf "%s (%s)\n" "$hook" "$(pacman -Qqo "$hook" 2>/dev/null || echo "owned by no package")"; grep -E "^(Operation|Target|When|Exec) *=" "$hook" | sed "s/^/    /"; done
/etc/pacman.d/hooks/90-mkinitcpio-install.hook (limine-mkinitcpio-hook)
    Operation = Install
    Operation = Upgrade
    Operation = Remove
    Target = usr/lib/initcpio/*
    Target = usr/lib/firmware/*
    Target = usr/lib/modules/*/extramodules/
    Target = usr/src/*/dkms.conf
    Target = usr/lib/systemd/systemd
    Target = usr/bin/cryptsetup
    Target = usr/bin/lvm
    Operation = Install
    Operation = Upgrade
    Target = usr/lib/modules/*/modules.builtin
    Operation = Install
    Operation = Upgrade
    Target = mkinitcpio
    Target = mkinitcpio-git
    When = PostTransaction
    Exec = /usr/share/libalpm/scripts/limine-mkinitcpio-install
/etc/pacman.d/hooks/99-omarchy-limine.hook (owned by no package)
    Operation = Upgrade
    Target = limine
    When = PostTransaction
    Exec = /bin/sh -c "/usr/bin/cp /usr/share/limine/BOOTX64.EFI /boot/EFI/limine/limine_x64.efi"
/usr/share/libalpm/hooks/10-limine-snapper-lock.hook (limine-snapper-sync)
    Operation = Upgrade
    Operation = Install
    Operation = Remove
    Target = *
    When = PreTransaction
    Exec = /usr/share/libalpm/scripts/limine-snapper-lock
/usr/share/libalpm/hooks/60-limine-mkinitcpio-remove-pre.hook (limine-mkinitcpio-hook)
    Operation = Remove
    Target = usr/lib/modules/*/modules.builtin
    When = PreTransaction
    Exec = /usr/share/libalpm/scripts/limine-mkinitcpio-remove pre
/usr/share/libalpm/hooks/80-limine-efi-deploy.hook (limine-mkinitcpio-hook)
    Operation = Install
    Operation = Upgrade
    Target = limine
    Target = limine-git
    Target = limine-dev
    Target = limine-mkinitcpio-hook
    Target = limine-mkinitcpio-hook-git
    When = PostTransaction
    Exec = /usr/bin/limine-install
/usr/share/libalpm/hooks/90-limine-mkinitcpio-remove-post.hook (limine-mkinitcpio-hook)
    Operation = Remove
    Target = usr/lib/modules/*/modules.builtin
    When = PostTransaction
    Exec = /usr/share/libalpm/scripts/limine-mkinitcpio-remove post
```

### Secure Boot variables

```text
$ bash -c for v in SecureBoot SetupMode AuditMode DeployedMode; do p=$(ls /sys/firmware/efi/efivars/${v}-* 2>/dev/null | head -1); if [[ -n $p ]]; then printf "%s=%s\n" "$v" "$(od -An -tu1 -j4 -N1 "$p" | tr -d " ")"; else printf "%s=absent\n" "$v"; fi; done
SecureBoot=1
SetupMode=0
AuditMode=0
DeployedMode=0
```

### sbctl status

```text
$ sbctl status
Installed:	✓ sbctl is installed
Owner GUID:	uuid-4
Setup Mode:	✓ Disabled
Secure Boot:	✓ Enabled
Vendor Keys:	microsoft builtin-db builtin-KEK
Firmware:	‼ Your firmware has known quirks
		- FQ0001: Defaults to executing on Secure Boot policy violation (CRITICAL)
		  https://github.com/Foxboron/sbctl/wiki/FQ0001
```

### sbctl list-files

```text
$ sbctl list-files
```

### sbctl verify

```text
$ sbctl verify
Verifying file database and EFI images in /boot...
✗ /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6 is not signed
✓ /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695 is signed
✗ /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3 is not signed
✗ /boot/EFI/BOOT/BOOTX64.EFI is not signed
✓ /boot/EFI/Linux/omarchy_linux-omarchy.efi is signed
✓ /boot/EFI/limine/limine_x64.efi is signed
```

### omasecboot status

```text
$ bash -c if command -v omasecboot >/dev/null; then omasecboot status; printf "exit status: %s\n" "$?"; else echo "omasecboot is not installed"; fi

OmaSecBoot - Status

  ✓ Secure Boot is on
  ✓ Your keys are enrolled in the firmware
  ! sbctl reports firmware quirk FQ0001: Defaults to executing on Secure Boot policy violation (CRITICAL); https://github.com/Foxboron/sbctl/wiki/FQ0001
  · Firmware quirks are hardware matches, not a test of the current policy; review the linked guidance and the firmware's Secure Boot image execution policy
  ✓ ENABLE_VERIFICATION=no is in effect
  ✓ ENABLE_ENROLL_LIMINE_CONFIG=yes is in effect
  ✓ The Limine loader is sealed over the current limine.conf and signed
  ✓ The fallback loader is upstream's raw copy, the rescue loader when Secure Boot is off
  ✓ sbctl's signing keys exist
  ✓ Signed: /boot/EFI/Linux/omarchy_linux-omarchy.efi
  ✓ Signed: /boot/EFI/limine/limine_x64.efi
  · 2 snapshot image(s) predate Secure Boot setup and are unsigned: those entries boot only with Secure Boot off. They leave with snapshot rotation, or within seconds when those snapshots are deleted (sudo snapper -c root delete NUMBER)
  ✓ The Windows entry restarts the machine into Windows Boot Manager
  ✓ The Limine hook is installed
  ✓ The watchers of limine.conf and the loader are active
  → Nothing to do
exit status: 0
```

### omasecboot windows status

```text
$ bash -c if command -v omasecboot >/dev/null; then omasecboot windows status 2>&1; else echo "omasecboot is not installed"; fi

OmaSecBoot - Windows

  ✓ Target: Boot0000, Windows Boot Manager
  ✓ limine.conf holds the entry for this target, once
  · The Windows entry is enabled
```

### BootNext

```text
$ bash -c p=$(ls /sys/firmware/efi/efivars/BootNext-* 2>/dev/null | head -1); if [[ -n $p ]]; then od -An -tx1 -j4 "$p"; else echo absent; fi
absent
```

### Watchers

```text
$ bash -c systemctl list-units --all --no-pager "omasecboot-watch@*" 2>&1; systemctl list-unit-files --no-pager "omasecboot-watch@*" 2>&1
  UNIT                                                    LOAD   ACTIVE   SUB     DESCRIPTION
  omasecboot-watch@boot-EFI-limine-limine_x64.efi.path    loaded active   waiting Watch /boot/EFI/limine/limine_x64.efi for OmaSecBoot
  omasecboot-watch@boot-limine.conf.path                  loaded active   waiting Watch /boot/limine.conf for OmaSecBoot
  omasecboot-watch@boot-EFI-limine-limine_x64.efi.service loaded inactive dead    Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed
  omasecboot-watch@boot-limine.conf.service               loaded inactive dead    Re-seal the Limine loader after /boot/limine.conf changed

Legend: LOAD   → Reflects whether the unit definition was properly loaded.
        ACTIVE → The high-level unit activation state, i.e. generalization of SUB.
        SUB    → The low-level unit activation state, values depend on unit type.

4 loaded units listed.
To show all installed unit files use 'systemctl list-unit-files'.
UNIT FILE                 STATE    PRESET
omasecboot-watch@.path    indirect disabled
omasecboot-watch@.service static   -

2 unit files listed.
```

### Boot entries (MAC and NVMe nodes redacted, raw bytes left out)

```text
$ boot_entries
BootCurrent: 0003
Timeout: 0 seconds
BootOrder: 0003,0000,0004
Boot0000* Windows Boot Manager	HD(1,GPT,uuid-1,0x800,0x64000)/\EFI\Microsoft\Boot\bootmgfw.efi (optional data left out)
Boot0003* Limine	HD(1,GPT,uuid-2,0x800,0x400000)/\EFI\limine\limine_x64.efi
Boot0004* UEFI OS	HD(1,GPT,uuid-2,0x800,0x400000)/\EFI\BOOT\BOOTX64.EFI (optional data left out)
```

### ESP mount, free space and partitions

```text
$ bash -c findmnt -o TARGET,SOURCE,FSTYPE,OPTIONS $esp 2>&1; df -h $esp 2>&1; lsblk -o NAME,SIZE,FSTYPE,PARTTYPENAME,MOUNTPOINTS 2>&1
TARGET SOURCE         FSTYPE OPTIONS
/boot  /dev/nvme1n1p1 vfat   rw,relatime,fmask=0077,dmask=0077,codepage=437,iocharset=ascii,shortname=mixed,utf8,errors=remount-ro
Filesystem      Size  Used Avail Use% Mounted on
/dev/nvme1n1p1  2.0G  1.1G 1018M  51% /boot
NAME          SIZE FSTYPE      PARTTYPENAME                 MOUNTPOINTS
zram0          31G swap                                     [SWAP]
nvme1n1     476.9G                                          
├─nvme1n1p1     2G vfat        EFI System                   /boot
└─nvme1n1p2 474.9G crypto_LUKS Linux root (x86-64)          
  └─root    474.9G btrfs                                    /var/log
                                                            /home
                                                            /var/cache/pacman/pkg
                                                            /
nvme0n1     931.5G                                          
├─nvme0n1p1   200M vfat        EFI System                   
├─nvme0n1p2    16M             Microsoft reserved           
├─nvme0n1p3 930.5G ntfs        Microsoft basic data         
└─nvme0n1p4   866M ntfs        Windows recovery environment 
```

### EFI files

```text
$ bash -c find $esp/EFI -type f \( -iname "*.efi" -o -name "*.efi_*" \) -exec sha256sum {} + 2>/dev/null | sort -k2
94308b4e9ee1783a65cfd60570240a80595baf125c5b18e729d3dd977194ad51  /boot/EFI/BOOT/BOOTX64.EFI
a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695  /boot/EFI/Linux/omarchy_linux-omarchy.efi
aaa999727d5cc105ef79307b8dea177a52719b511c39eebf5984e00a8d169136  /boot/EFI/limine/limine_x64.efi
```

### Snapshot images kept by limine-snapper-sync

```text
$ bash -c find $esp -path "*/limine_history/*" -type f -exec sha256sum {} + 2>/dev/null | sort -k2
521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6  /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6
a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695  /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695
cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3  /boot/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3
f8292492bd6d6eb3ac6a1350ec0040fe75aef6b12ef458aba12f3a682386f61e  /boot/id-1/limine_history/snapshots.json
b7001369dbdc3b055d7db0aabc22910732d1d07c3abeffa10d03e4998adbdf72  /boot/id-1/limine_history/snapshots.json.old
```

### Snapshot list kept by limine-snapper-sync (first 60 lines)

```text
$ bash -c find $esp -path "*/limine_history/snapshots.json" -exec head -n 60 {} + 2>&1
{
  "jsonFormatVersion" : "1.3.0",
  "lastSnapshotID" : 4,
  "lastTimestamp" : "2026-10-18 22:33:39",
  "lastUTCTime" : "2026-10-18 17:03:39",
  "properties" : {
    "SNAPSHOTS_PATH" : "/@/.snapshots",
    "SUBVOLUME_PATH" : "/@"
  },
  "snapshotEntries" : [ {
    "snapperID" : {
      "snapshotID" : 1,
      "utcTime" : "2026-10-18 10:08:21",
      "timestamp" : "2026-10-18 15:38:21",
      "properties" : {
        "description" : "4.0.4-1",
        "type" : "single"
      }
    },
    "kernelEntries" : [ {
      "kernelVersion" : "linux-omarchy",
      "leadingSpaces" : "  ",
      "optionDetails" : [ {
        "limineKey" : "COMMENT",
        "leadingSpaces" : "  ",
        "lineIndex" : 0,
        "optionLine" : "Kernel version: 7.2.5-3-omarchy",
        "snapshotOptionLine" : "Kernel version: 7.2.5-3-omarchy",
        "properties" : { }
      }, {
        "limineKey" : "COMMENT",
        "leadingSpaces" : "  ",
        "lineIndex" : 1,
        "optionLine" : "kernel-id=linux-omarchy",
        "snapshotOptionLine" : "kernel-id=linux-omarchy",
        "properties" : { }
      }, {
        "limineKey" : "PROTOCOL",
        "leadingSpaces" : "  ",
        "lineIndex" : 2,
        "optionLine" : "efi",
        "snapshotOptionLine" : "efi",
        "properties" : { }
      } ],
      "imageDetails" : [ {
        "limineKey" : "PATH",
        "leadingSpaces" : "  ",
        "lineIndex" : 3,
        "fileName" : "omarchy_linux-omarchy.efi",
        "fileHashName" : "omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6",
        "dirPath" : "/EFI/Linux/",
        "filePathLine" : "/EFI/Linux/omarchy_linux-omarchy.efi",
        "snapshotFilePathLine" : "/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6#099ef9a0a25a193e749100c3d69d803f758bae68e252002a06e14a8ec2c4a9739bb2898117d60c556cf6c7aa1904aa2d8d42c43111477556d0b38cbaa40b5234",
        "properties" : {
          "PATH_RESOURCE" : "boot():",
          "HASH" : "#099ef9a0a25a193e749100c3d69d803f758bae68e252002a06e14a8ec2c4a9739bb2898117d60c556cf6c7aa1904aa2d8d42c43111477556d0b38cbaa40b5234"
        }
      } ],
      "cmdlineDetails" : [ {
        "limineKey" : "CMDLINE",
```

### Snapshots

```text
$ bash -c snapper -c root list 2>&1
# │ Type   │ Pre # │ Date                     │ User │ Cleanup │ Description                                   │ Userdata
──┼────────┼───────┼──────────────────────────┼──────┼─────────┼───────────────────────────────────────────────┼─────────
0 │ single │       │                          │ root │         │ current                                       │
1 │ single │       │ Sun Oct 18 15:38:21 2026 │ root │ number  │ 4.0.4-1                                       │
2 │ single │       │ Sun Oct 18 16:29:48 2026 │ root │ number  │ 4.0.5-1                                       │
3 │ single │       │ Sun Oct 18 20:47:57 2026 │ root │         │ OmaSecBoot signed boot files; Secure Boot off │
4 │ single │       │ Sun Oct 18 22:33:39 2026 │ root │ number  │ 4.0.5-1                                       │
```

### Limine loader directories

```text
$ bash -c ls -la $esp/EFI/limine $esp/EFI/BOOT 2>&1
/boot/EFI/BOOT:
total 376
drwx------ 2 root root   4096 Oct 18 15:21 .
drwx------ 6 root root   4096 Oct 18 21:13 ..
-rwx------ 1 root root 376832 Oct 18 15:41 BOOTX64.EFI

/boot/EFI/limine:
total 752
drwx------ 2 root root   4096 Oct 18 22:33 .
drwx------ 6 root root   4096 Oct 18 21:13 ..
-rwx------ 1 root root 378880 Oct 18 15:41 limine_x64.bak
-rwx------ 1 root root 378936 Oct 18 22:33 limine_x64.efi
```

### Limine path hashes versus files

```text
$ bash -c grep -o "boot():/[^#[:space:]]*#[0-9A-Fa-f]\{128\}" $esp/limine.conf 2>/dev/null | sort -u | while IFS= read -r uri; do file="$esp/${uri#boot():/}"; file="${file%#*}"; hash="${uri##*#}"; if [ -f "$file" ]; then actual=$(b2sum "$file" | cut -d" " -f1); [ "$actual" = "$hash" ] && printf "match  %s\n" "$uri" || printf "STALE  %s\n" "$uri"; else printf "absent %s\n" "$uri"; fi; done; true
match  boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6#099ef9a0a25a193e749100c3d69d803f758bae68e252002a06e14a8ec2c4a9739bb2898117d60c556cf6c7aa1904aa2d8d42c43111477556d0b38cbaa40b5234
match  boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3#19a70ec0bd5d2ee0f2d35d97b615564007ba3cedcf39a3e2aa70182257aa574706e60227de550f793cf143a08bdf9dfb82fe36dc6cf748d8047fd3ff6cfc312f
```

### Config checksum in each loader (first 16 hex digits)

```text
$ bash -c for f in $esp/EFI/limine/limine_x64.efi $esp/EFI/BOOT/BOOTX64.EFI; do h=$(grep -a -o "++CONFIG_B2SUM_SIGNATURE++[0-9a-f]\{128\}" "$f" 2>/dev/null | head -1 | cut -c27-42); printf "%s: %s\n" "$f" "${h:-absent}"; done; printf "limine.conf b2sum: "; b2sum $esp/limine.conf | cut -c1-16
/boot/EFI/limine/limine_x64.efi: 2ad6d11394f48e51
/boot/EFI/BOOT/BOOTX64.EFI: 0000000000000000
limine.conf b2sum: 2ad6d11394f48e51
```

### Limine config layers (owner, mode, links)

```text
$ bash -c stat -c "%U:%G %a %h %n" /etc/default/limine /etc/limine-entry-tool.conf /etc/limine-entry-tool.d/*.conf /usr/share/limine-entry-tool.d/*.conf 2>&1
root:root 644 1 /etc/default/limine
root:root 644 1 /etc/limine-entry-tool.conf
root:root 644 1 /etc/limine-entry-tool.d/omarchy-defaults.conf
root:root 644 1 /etc/limine-entry-tool.d/omarchy-uki.conf
root:root 644 1 /etc/limine-entry-tool.d/resume.conf
stat: cannot statx '/usr/share/limine-entry-tool.d/*.conf': No such file or directory
```

### Limine drop-in settings

```text
$ bash -c grep -H -v "^[[:space:]]*#" /etc/limine-entry-tool.d/*.conf /usr/share/limine-entry-tool.d/*.conf 2>&1 | grep -v ":$"
/etc/limine-entry-tool.d/omarchy-defaults.conf:TARGET_OS_NAME="Omarchy"
/etc/limine-entry-tool.d/omarchy-defaults.conf:KERNEL_CMDLINE[default]+=" quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0"
/etc/limine-entry-tool.d/omarchy-defaults.conf:KERNEL_CMDLINE[default]+=" initramfs_async=0"
/etc/limine-entry-tool.d/omarchy-defaults.conf:KERNEL_CMDLINE[default]+=" systemd.tty.term.console=dumb"
/etc/limine-entry-tool.d/omarchy-defaults.conf:CUSTOM_UKI_NAME="omarchy"
/etc/limine-entry-tool.d/omarchy-defaults.conf:ENABLE_LIMINE_FALLBACK=yes
/etc/limine-entry-tool.d/omarchy-defaults.conf:FIND_BOOTLOADERS=yes
/etc/limine-entry-tool.d/omarchy-defaults.conf:BOOT_ORDER="linux-t2, linux-omarchy, linux-omarchy-*, *, *fallback, Snapshots"
/etc/limine-entry-tool.d/omarchy-defaults.conf:MAX_SNAPSHOT_ENTRIES=6
/etc/limine-entry-tool.d/omarchy-defaults.conf:SNAPSHOT_FORMAT_CHOICE=5
/etc/limine-entry-tool.d/omarchy-uki.conf:ENABLE_UKI=yes
/etc/limine-entry-tool.d/resume.conf:KERNEL_CMDLINE[default]+=" resume=/dev/mapper/root resume_offset=1906319"
grep: /usr/share/limine-entry-tool.d/*.conf: No such file or directory
```

### /etc/default/limine

```text
ESP_PATH="/boot"

KERNEL_CMDLINE[default]+="cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=@ rw rootfstype=btrfs"
ENABLE_VERIFICATION=no
ENABLE_ENROLL_LIMINE_CONFIG=yes
```

### limine.conf

```text
### Read more at config document: https://github.com/limine-bootloader/limine/blob/trunk/CONFIG.md
#timeout: 3
default_entry: 2
interface_branding: Omarchy Bootloader
interface_branding_color: 9ece6a
interface_help_color: 9ece6a
interface_help_color_bright: 9ece6a
hash_mismatch_panic: no

term_background: 1a1b26
backdrop: 1a1b26

# Terminal colors (Tokyo Night palette)
term_palette: 15161e;f7768e;9ece6a;e0af68;7aa2f7;bb9af7;7dcfff;a9b1d6
term_palette_bright: 414868;f7768e;9ece6a;e0af68;7aa2f7;bb9af7;7dcfff;c0caf5

# Text colors
term_foreground: c0caf5
term_foreground_bright: c0caf5
term_background_bright: 24283b
/+Omarchy
### This OS entry is auto-generated by limine-entry-tool
comment: Omarchy
comment: machine-id=id-1 order-priority=50 
  //linux-omarchy
  ### This kernel entry is auto-generated by limine-entry-tool
  comment: Kernel version: 7.2.8-9-omarchy
  comment: kernel-id=linux-omarchy 
  protocol: efi
  path: boot():/EFI/Linux/omarchy_linux-omarchy.efi
  cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=@ rw rootfstype=btrfs resume=/dev/mapper/root resume_offset=1906319 systemd.tty.term.console=dumb initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0

     //Snapshots
     ### Auto-generated by limine-snapper-sync
     comment: 4 snapshots
     ///4 │ 2026-10-18 22:33:39
     comment: 4.0.5-1
     ////linux-omarchy
     comment: Kernel version: 7.2.8-9-omarchy
     comment: kernel-id=linux-omarchy
     protocol: efi
     path: boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695
     cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=/@/.snapshots/4/snapshot rw rootfstype=btrfs resume=/dev/mapper/root resume_offset=1906319 systemd.tty.term.console=dumb initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0
     ///3 │ 2026-10-18 20:47:57
     comment: OmaSecBoot signed boot files; Secure Boot off
     ////linux-omarchy
     comment: Kernel version: 7.2.8-9-omarchy
     comment: kernel-id=linux-omarchy
     protocol: efi
     path: boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_a1717637ddca1a440b6f6a76f1477668705113c68bb98c21048270c61b2a0695
     cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=/@/.snapshots/3/snapshot rw rootfstype=btrfs resume=/dev/mapper/root resume_offset=1906319 systemd.tty.term.console=dumb initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0
     ///2 │ 2026-10-18 16:29:48
     comment: 4.0.5-1
     ////linux-omarchy
     comment: Kernel version: 7.2.8-9-omarchy
     comment: kernel-id=linux-omarchy
     protocol: efi
     path: boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_cb36c7a9f3005be9edfbc97daebce62f7a592dc8f0b462caff62ac6798f72cf3#19a70ec0bd5d2ee0f2d35d97b615564007ba3cedcf39a3e2aa70182257aa574706e60227de550f793cf143a08bdf9dfb82fe36dc6cf748d8047fd3ff6cfc312f
     cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=/@/.snapshots/2/snapshot rw rootfstype=btrfs resume=/dev/mapper/root resume_offset=1906319 systemd.tty.term.console=dumb initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0
     ///1 │ 2026-10-18 15:38:21
     comment: 4.0.4-1
     ////linux-omarchy
     comment: Kernel version: 7.2.5-3-omarchy
     comment: kernel-id=linux-omarchy
     protocol: efi
     path: boot():/id-1/limine_history/omarchy_linux-omarchy.efi_sha256_521058f0bd2fc44d5c8f8598e00c10e6b31a552590813dbdffc009041e9487c6#099ef9a0a25a193e749100c3d69d803f758bae68e252002a06e14a8ec2c4a9739bb2898117d60c556cf6c7aa1904aa2d8d42c43111477556d0b38cbaa40b5234
     cmdline: cryptdevice=PARTUUID=uuid-3:root root=/dev/mapper/root zswap.enabled=0 rootflags=subvol=/@/.snapshots/1/snapshot rw rootfstype=btrfs  resume=/dev/mapper/root resume_offset=1906319 initramfs_async=0 quiet splash loglevel=0 systemd.show_status=false rd.udev.log_level=0 vt.global_cursor_default=0

/EFI fallback
### This EFI entry is auto-generated by limine-entry-tool
comment: Default EFI loader
comment: order-priority=10 
protocol: efi
path: boot():/EFI/BOOT/BOOTX64.EFI


/Windows
    comment: Windows Boot Manager through the firmware, managed by OmaSecBoot
    protocol: efi_boot_entry
    entry: Windows Boot Manager
```

### State directory

```text
$ bash -c ls -laR /var/lib/omasecboot 2>&1 | grep -v '^$'
/var/lib/omasecboot:
total 4
drwxr-xr-x 1 root root 110 Oct 18 22:11 .
drwxr-xr-x 1 root root 400 Oct 18 20:46 ..
-rw-r--r-- 1 root root   0 Oct 18 21:10 enabled
drwxr-xr-x 1 root root  32 Oct 18 20:46 firmware-backup
-rw-r--r-- 1 root root  62 Oct 18 20:46 settings-originals
-rw-r--r-- 1 root root   0 Oct 18 22:11 windows-enabled
/var/lib/omasecboot/firmware-backup:
total 0
drwxr-xr-x 1 root root  32 Oct 18 20:46 .
drwxr-xr-x 1 root root 110 Oct 18 22:11 ..
drwx------ 1 root root  50 Oct 18 20:46 20261018T151648Z
/var/lib/omasecboot/firmware-backup/20261018T151648Z:
total 52
drwx------ 1 root root    50 Oct 18 20:46 .
drwxr-xr-x 1 root root    32 Oct 18 20:46 ..
-rw------- 1 root root  3888 Oct 18 20:46 KEK
-rw------- 1 root root   821 Oct 18 20:46 PK
-rw------- 1 root root   350 Oct 18 20:46 SHA256SUMS
-rw------- 1 root root  8458 Oct 18 20:46 db
-rw------- 1 root root 21420 Oct 18 20:46 dbx
-rw------- 1 root root    25 Oct 18 20:46 modes
```

### Firmware backups (names and sizes only)

```text
$ bash -c find /var/lib/omasecboot/firmware-backup -type f -printf '%s %p\n' 2>/dev/null | sort -k2
3888 /var/lib/omasecboot/firmware-backup/20261018T151648Z/KEK
821 /var/lib/omasecboot/firmware-backup/20261018T151648Z/PK
350 /var/lib/omasecboot/firmware-backup/20261018T151648Z/SHA256SUMS
8458 /var/lib/omasecboot/firmware-backup/20261018T151648Z/db
21420 /var/lib/omasecboot/firmware-backup/20261018T151648Z/dbx
25 /var/lib/omasecboot/firmware-backup/20261018T151648Z/modes
```

### settings-originals

```text
ENABLE_VERIFICATION	absent
ENABLE_ENROLL_LIMINE_CONFIG	absent
```

### needs-attention

_absent_

### This boot's journal for omasecboot, limine, sbctl (last 200 lines)

```text
$ bash -c journalctl -b --no-pager -o short-iso 2>/dev/null | grep -i -E 'omasecboot|limine|sbctl|efibootmgr' | tail -200
2026-10-18T22:17:20+05:30 host systemd[1]: Started Watch /boot/EFI/limine/limine_x64.efi for OmaSecBoot.
2026-10-18T22:17:20+05:30 host systemd[1]: Started Watch /boot/limine.conf for OmaSecBoot.
2026-10-18T22:17:20+05:30 host systemd[1]: Started [limine-snapper-sync.service] automatically synchronizes boot entries with the Snapper snapshot list..
2026-10-18T22:17:23+05:30 host systemd[1271]: Starting Limine-snapper-restore notification...
2026-10-18T22:17:23+05:30 host systemd[1271]: Started Limine-snapper-restore notification.
2026-10-18T22:17:23+05:30 host limine-snapper-restore[1690]: You are not in a snapshot.
2026-10-18T22:27:16+05:30 host systemd[1]: Created slice Slice /system/omasecboot-watch.
2026-10-18T22:27:16+05:30 host systemd[1]: Starting Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed...
2026-10-18T22:27:16+05:30 host systemd[1]: Starting Re-seal the Limine loader after /boot/limine.conf changed...
2026-10-18T22:27:16+05:30 host limine-snapper-sync[339930]: Updated: /boot/limine.conf
2026-10-18T22:27:16+05:30 host limine-snapper-sync[340018]: Config file BLAKE2B successfully enrolled.
2026-10-18T22:27:17+05:30 host limine-snapper-sync[340034]: ✓ Signed /boot/EFI/limine/limine_x64.efi
2026-10-18T22:27:17+05:30 host systemd[1]: omasecboot-watch@boot-EFI-limine-limine_x64.efi.service: Deactivated successfully.
2026-10-18T22:27:17+05:30 host systemd[1]: Finished Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed.
2026-10-18T22:27:18+05:30 host systemd[1]: omasecboot-watch@boot-limine.conf.service: Deactivated successfully.
2026-10-18T22:27:18+05:30 host systemd[1]: Finished Re-seal the Limine loader after /boot/limine.conf changed.
2026-10-18T22:31:38+05:30 host sudo[345361]:      user : TTY=pts/1 ; PWD=/home/user ; USER=root ; COMMAND=/usr/bin/omasecboot status
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[1219]: [EVENT] CREATE,ISDIR -> 4
2026-10-18T22:33:39+05:30 host systemd[1]: Starting Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed...
2026-10-18T22:33:39+05:30 host systemd[1]: Starting Re-seal the Limine loader after /boot/limine.conf changed...
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[348187]: Saved: /boot/id-1/limine_history/snapshots.json
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[348187]: Updated: /boot/limine.conf
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[348363]: Config file BLAKE2B successfully enrolled.
2026-10-18T22:33:39+05:30 host limine-snapper-watcher[348378]: ✓ Signed /boot/EFI/limine/limine_x64.efi
2026-10-18T22:33:40+05:30 host systemd[1]: omasecboot-watch@boot-EFI-limine-limine_x64.efi.service: Deactivated successfully.
2026-10-18T22:33:40+05:30 host systemd[1]: Finished Re-seal the Limine loader after /boot/EFI/limine/limine_x64.efi changed.
2026-10-18T22:33:43+05:30 host systemd[1]: omasecboot-watch@boot-limine.conf.service: Deactivated successfully.
2026-10-18T22:33:43+05:30 host systemd[1]: Finished Re-seal the Limine loader after /boot/limine.conf changed.
2026-10-18T22:53:20+05:30 host pkexec[433525]: user: Executing command [USER=root] [TTY=unknown] [CWD=/home/user/Documents/github/omasecboot] [COMMAND=/usr/bin/bash -c set -euo pipefail; export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/home/user/Documents/github/omasecboot; cd /home/user/Documents/github/omasecboot; /usr/bin/bash tests/acceptance-record.sh 2-status-msi-current -- /usr/bin/omasecboot status; chown user:user acceptance-records/*-2-status-msi-current.md]
```
